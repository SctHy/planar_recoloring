#!/usr/bin/env python3
"""Reject intentionally corrupted rotations, patch witnesses and count ledgers."""
import argparse
from copy import deepcopy
import gzip,json,sys
from pathlib import Path
from plane import need,rotation,spherical,girth_five,hinge,patches,check_partner
from check_geometry import near_ledger,global_ledger
from check_algebra import admissible_chain,chain_lower
ROOT=Path(__file__).resolve().parent


def run():
    data=json.loads(gzip.decompress((ROOT/'data/fixtures.json.gz').read_bytes()))['fixtures']
    row=next(x for x in data if x['category']=='D10-no-ordinary')
    r=rotation(row['rotation']);fs,ow=spherical(r);P=next(p for p in patches(r,fs)if p['kind']=='hinge')
    outcomes=[]
    def reject(name,f):
        try:f()
        except ValueError:outcomes.append(name)
        else:raise ValueError('corruption was accepted: '+name)
    bad=deepcopy(row['rotation']);bad[0].append(bad[0][0])
    reject('repeated-neighbour',lambda:rotation(bad))
    bad2=deepcopy(row['rotation']);u=0;v=bad2[u][0];bad2[v].remove(u)
    reject('asymmetric-adjacency',lambda:rotation(bad2))
    bad3=deepcopy(r);q=next(v for v in r if len(r[v])==4);bad3[q]=tuple(reversed(bad3[q]))
    reject('nonspherical-local-rotation',lambda:spherical(bad3))
    first=list(fs[P['face_ids'][0]]);first[1]=first[0]
    reject('repeated-pentagon-vertex',lambda:hinge(r,first,fs[P['face_ids'][1]]))
    reject('identical-two-face-witness',lambda:hinge(r,fs[P['face_ids'][0]],fs[P['face_ids'][0]]))
    reject('nonseparated-product-factors',lambda:check_partner(r,fs,P['face_ids'],P['face_ids']))
    L=near_ledger(r,fs,ow,P);wrong=dict(L);wrong['nu']+=1
    reject('altered-equality-ledger',lambda:global_ledger(r,fs,P,wrong))
    # A claimed insufficient-cost chain must be rejected by the independently stated bound.
    def false_chain():
        x=('4','4','4','4')
        need(admissible_chain(x),'chain premise')
        need(chain_lower(x)<=1,'false one-unit chain budget')
    reject('false-one-unit-four-attachment-chain',false_chain)
    return {'status':'PASS','count':len(outcomes),'rejected':outcomes,
            'scope':'Intentional corruptions test checks, not the truth of unbounded analytic arguments.'}


def main():
    need(not sys.flags.optimize,'optimized Python is not supported')
    p=argparse.ArgumentParser();p.add_argument('--write-reports',action='store_true');args=p.parse_args()
    text=json.dumps(run(),sort_keys=True,indent=2)+'\n';target=ROOT/'reports/negative.json'
    if args.write_reports:target.write_text(text)
    else:need(target.read_text()==text,'negative report differs')
    print('PASS eight corruptions rejected')
if __name__=='__main__':main()
