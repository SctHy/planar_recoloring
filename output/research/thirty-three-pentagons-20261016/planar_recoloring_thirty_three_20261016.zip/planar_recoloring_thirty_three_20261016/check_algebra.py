#!/usr/bin/env python3
"""Exact finite regressions of identities and the low-degree case extraction."""
import argparse
from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
import sys
from plane import need
ROOT=Path(__file__).resolve().parent


def admissible_chain(x):
    # L denotes degree three, 4 and 5 are original attachment degrees.
    return all({a,b} not in ({'L'},{'L','4'}) for a,b in zip(x,x[1:]))


def chain_lower(x):
    # The three SS faces are distinct. This lower bound is deliberately conservative.
    w=sum(2-(a=='4')-(b=='4') for a,b in zip(x,x[1:]) if a!='L' and b!='L')
    delta=sum(x[i]=='4' and x[i-1]!='L' and x[i+1]!='L' for i in (1,2))
    # At an internal light attachment its third face contains two degree-five vertices.
    # Do not add that term to the SS counts: taking a maximum cannot double count it.
    return max(w+delta, 2 if 'L' in x[1:3] else 0)


def run():
    identity_checks=0
    for a,b,e,Q,beta in product(range(18),range(10),range(5),range(5),range(4)):
        h=a+b;D=a+2*b+e;p=12+2*D+Q;Delta=3*h-D-12-Q
        C=3*h+D-3*a
        upper=15+C-1+Delta-3*beta
        need(p-upper==10-D+3*e+2*Q+3*beta,'global subtraction identity')
        identity_checks+=1
    residues={}
    for D in (10,11):
        residues[str(D)]=[(a,b)for a in range(D+1)for b in range(D+1)
                           if a+2*b==D and 2*a+b-12>=0]
    need(residues['10']==[(6,2),(8,1),(10,0)],'D10 residual degrees')
    need(residues['11']==[(5,3),(7,2),(9,1),(11,0)],'D11 residual degrees')
    subsets=[]
    for k in range(7):
        for s in combinations(range(6),k):
            if all(min((a-b)%6,(b-a)%6)>=3 for a,b in combinations(s,2)):
                subsets.append(s)
    need(max(map(len,subsets))==2,'hexagon has three possible hub neighbours')
    memberships=[]
    for j in range(4):
        hinges=[i for i in range(4)if j in {i,(i+1)%4,(i+2)%4}]
        specials=[(i+1)%4 for i in hinges]
        need(len(hinges)==len(set(specials))==3,'three rotated hinges')
        memberships.append({'spoke':j,'hinges':hinges,'special_spokes':specials})
    chains=[]
    for x in product(('L','4','5'),repeat=4):
        if not admissible_chain(x):continue
        bound=chain_lower(x);need(bound>=2,'four-attachment chain lower bound')
        chains.append({'word':''.join(x),'minimum_delta_plus_W':bound})
    # These enumerate necessary numerical conditions, not graph realizations.
    low_p=[]
    for s,t,b,kappa,Q,e,sigma,Dp in product(range(2,12),range(1,12),range(1,23),
                                         range(2),range(3),range(2),range(5),range(13,20)):
        if s+t<4 or b>2*t:continue
        if kappa and s!=2:continue
        if t>=2 and b<2:continue
        if s==2 and t<2:continue
        if Dp<12+b-kappa+2*Q+3*e+sigma:continue
        p=6+2*t+2*Dp+Q
        if p>37:continue
        if s==3 and t==1: reason='inherited star3'
        elif s==2:
            need((t,b,kappa,Q,e,sigma,Dp)==(2,2,1,0,0,0,13), 'unlisted two-S p<=37 tuple')
            reason='light attachments; no SS face; alternating tailed5'
        else:
            need(t==1 and s>=4 and Q==e==0 and sigma<=1, 'unlisted long-chain p<=37 tuple')
            reason='four-attachment chain forces delta+W>=2'
        low_p.append({'s':s,'t':t,'b':b,'kappa':kappa,'Q':Q,'e':e,
                      'sigma':sigma,'Dprime':Dp,'p':p,'exclusion':reason})
    # For a bounded excess, s+t-3 is the hub's positive contribution.
    low_D=[]
    for s,t,b,kappa,Q,e,sigma,Dp in product(range(2,16),range(1,16),range(1,31),
                                         range(2),range(3),range(2),range(4),range(13,17)):
        if s+t<4 or b>2*t or (kappa and s!=2):continue
        if (t>=2 and b<2) or (s==2 and t<2):continue
        if Dp<12+b-kappa+2*Q+3*e+sigma:continue
        D=Dp+s+t-3
        if D>15:continue
        if s==3 and t==1:reason='inherited star3'
        elif s>=3:
            need((s,t,b,kappa,Q,e,sigma,Dp)==(4,1,1,0,0,0,0,13),'unlisted large-S D<=15 case')
            reason='four-attachment chain'
        elif t==2:
            need(Q==e==0 and b<=3,'unlisted degree-four hub case')
            if kappa:
                need(sigma<=1,'light two-S slack')
                reason='exceptional light attachments; no SS face; tailed5'
            else:
                need(b==2 and sigma==0 and Dp==14,'nonexceptional degree-four hub')
                reason='p0>=2 ensures a mixed p0 face; tailed5'
        else:
            need((t,b,kappa,Q,e,sigma,Dp)==(3,2,1,0,0,0,13),'unlisted degree-five hub case')
            reason='no SS face; Z-runs of lengths one and two cost at least three'
        low_D.append({'s':s,'t':t,'b':b,'kappa':kappa,'Q':Q,'e':e,
                      'sigma':sigma,'Dprime':Dp,'D':D,'exclusion':reason})
    # Circular-word lower bound for b, with the inherited length-two-run improvement.
    circular_checks=0
    for s in range(2,8):
        for t in range(1,6):
            n=s+t
            for Z in combinations(range(n),t):
                if 0 in Z:continue # fix one S position; not an isomorphism quotient claim
                word=['Z' if i in Z else 'S' for i in range(n)]
                runs=[];i=1
                while i<n:
                    if word[i]=='S':i+=1;continue
                    j=i
                    while j<n and word[j]=='Z':j+=1
                    runs.append(j-i);i=j
                cost=sum(1 if l==1 else 2 if l==2 else l-1 for l in runs)
                need(cost>=1 and (t==1 or cost>=2),'Z-run minimum')
                if s==2 and t==3 and len(runs)==2:
                    need(cost>=3,'two Z-runs with three vertices')
                circular_checks+=1
    return {'status':'PASS','scope':'Finite exact identity/case regressions; analytic incidence and structural arguments are not machine-proved.',
            'scalar_identity_checks':identity_checks,'D10_D11_degree_residues':residues,
            'hexagon_hub_neighbour_subsets':len(subsets),'maximum_hub_neighbours_on_hexagon':2,
            'rotated_hinge_memberships':memberships,'four_attachment_chains':chains,
            'low_p_tuples':low_p,'low_D_tuples':low_D,'circular_word_checks':circular_checks,
            'low_p_tuple_count':len(low_p),'low_D_tuple_count':len(low_D)}


def main():
    need(not sys.flags.optimize,'optimized Python is not supported')
    p=argparse.ArgumentParser();p.add_argument('--write-reports',action='store_true');args=p.parse_args()
    text=json.dumps(run(),sort_keys=True,indent=2)+'\n';target=ROOT/'reports/algebra.json'
    if args.write_reports:target.write_text(text)
    else:need(target.read_text()==text,'algebra report differs')
    print('PASS exact equality algebra and low-degree case extraction')
if __name__=='__main__':main()
