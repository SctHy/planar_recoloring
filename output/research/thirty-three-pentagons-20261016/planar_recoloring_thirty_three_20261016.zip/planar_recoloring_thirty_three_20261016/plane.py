#!/usr/bin/env python3
"""Small exact plane-graph utilities; no geometry or numerical library is used."""
from itertools import combinations


def need(condition, message):
    if not condition:
        raise ValueError(message)


def rotation(raw):
    r = {int(v): tuple(row) for v, row in
         (enumerate(raw) if isinstance(raw, list) else raw.items())}
    need(set(r) == set(range(len(r))), 'nonconsecutive vertex labels')
    for v, row in r.items():
        need(len(set(row)) == len(row) and v not in row, 'loop/repeated neighbour')
        need(all(type(u) is int and u in r and v in r[u] for u in row),
             'asymmetric rotation adjacency')
    return r


def faces(r):
    left = {(u, v) for u, row in r.items() for v in row}
    out, owner = [], {}
    while left:
        start = min(left)
        arc, f = start, []
        while arc in left:
            left.remove(arc)
            u, v = arc
            f.append(u)
            owner[arc] = len(out)
            row = r[v]
            arc = (v, row[(row.index(u) + 1) % len(row)])
        need(arc == start, 'face permutation did not close')
        out.append(tuple(f))
    return out, owner


def connected(r):
    if not r:
        return False
    seen, stack = {min(r)}, [min(r)]
    while stack:
        for v in r[stack.pop()]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == len(r)


def spherical(r):
    need(connected(r), 'graph is disconnected')
    fs, owner = faces(r)
    need(len(r) - sum(map(len, r.values())) // 2 + len(fs) == 2,
         'rotation does not have spherical Euler characteristic')
    return fs, owner


def girth_five(r):
    for u in r:
        N, seen = set(r[u]), set()
        for v in N:
            need(not N.intersection(r[v]), 'triangle')
            other = set(r[v]) - {u}
            need(not seen.intersection(other), 'four-cycle')
            seen.update(other)
    return True


def pentagons(r):
    out = set()
    def extend(root, path):
        if len(path) == 5:
            if root in r[path[-1]] and path[1] < path[-1]:
                out.add(tuple(path))
            return
        for v in r[path[-1]]:
            if v > root and v not in path:
                extend(root, path + [v])
    for v in r:
        extend(v, [v])
    return out


def separated(r, X, Y):
    X, Y = set(X), set(Y)
    return not X.intersection(Y) and not any(set(r[v]).intersection(Y) for v in X)


def cycle_ok(r, f):
    f = tuple(f)
    need(len(f) == len(set(f)) == 5, 'not a simple pentagon')
    need(all(v in r[u] for u, v in zip(f, f[1:] + f[:1])), 'missing pentagon edge')


def hinge(r, f, g):
    """Validate the precise inherited eight-vertex factor, including its ports."""
    f, g = tuple(f), tuple(g)
    cycle_ok(r, f); cycle_ok(r, g)
    shared = set(f).intersection(g)
    need(len(shared) == 2, 'hinge intersection is not an edge')
    centres = [v for v in shared if len(r[v]) == 4]
    need(len(centres) == 1, 'hinge centre does not have original degree four')
    q = centres[0]
    z = next(iter(shared - {q}))
    need(z in r[q], 'missing common edge')
    def order(c):
        i = c.index(q)
        c = c[i:] + c[:i]
        if c[1] == z:
            c = (q,) + tuple(reversed(c[1:]))
        need(c[-1] == z, 'wrong hinge orientation')
        return c
    f, g = order(f), order(g)
    word = (q, z) + f[1:-1] + g[1:-1]
    X = set(word)
    need(len(X) == 8 and all(len(r[v]) == 3 for v in X - {q}),
         'incorrect noncentral original degrees')
    base = {(0,1),(0,2),(2,3),(3,4),(1,4),(0,5),(5,6),(6,7),(1,7)}
    actual = {tuple(sorted((word.index(u), word.index(v))))
              for u in X for v in r[u] if v in X}
    need(base <= actual and actual - base in (set(), {(3,6)}), 'unlisted hinge chord')
    chord = bool(actual - base)
    roles = (0,2,4,5,7) if chord else (0,2,3,4,5,6,7)
    contacts = {}
    for v in roles:
        outside = set(r[word[v]]) - X
        need(len(outside) == 1, 'wrong exterior contact')
        contacts[v] = next(iter(outside))
    return dict(kind='hinge', centre=q, word=word, X=X, chord=chord,
                contacts=contacts, B=set(contacts.values()))


def bowtie(r, f, g):
    f, g = tuple(f), tuple(g)
    cycle_ok(r, f); cycle_ok(r, g)
    common = set(f).intersection(g)
    need(len(common) == 1, 'bowtie intersection is not a single vertex')
    q = next(iter(common)); X = set(f).union(g)
    need(len(r[q]) == 4 and len(X) == 9 and
         all(len(r[v]) == 3 for v in X - {q}), 'incorrect bowtie degrees')
    base = {tuple(sorted(e)) for c in (f,g) for e in zip(c,c[1:]+c[:1])}
    actual = {tuple(sorted((u,v))) for u in X for v in r[u] if v in X}
    extra = actual-base
    need(len(extra) <= 1, 'too many bowtie chords')
    need(all(q not in (u,v) and q not in r[u] and q not in r[v] for u,v in extra),
         'bowtie chord is not middle-to-middle')
    return dict(kind='bowtie', centre=q, X=X)


def patches(r, fs):
    heavy = {v for v in r if len(r[v]) >= 4}
    out = []
    for q in sorted(heavy):
        if len(r[q]) != 4:
            continue
        clean = [(i,f) for i,f in enumerate(fs) if len(f) == 5 and set(f)&heavy == {q}]
        for (i,f),(j,g) in combinations(clean,2):
            common = set(f)&set(g)
            p = hinge(r,f,g) if len(common) == 2 else bowtie(r,f,g)
            p['face_ids'] = (i,j)
            out.append(p)
    return out


def check_partner(r, fs, first_ids, second_ids):
    need(len(first_ids) == len(second_ids) == 2, 'two faces per factor required')
    a = hinge(r, *(fs[i] for i in first_ids))
    f,g = (fs[i] for i in second_ids)
    b = hinge(r,f,g) if len(set(f)&set(g)) == 2 else bowtie(r,f,g)
    need(separated(r,a['X'],b['X']), 'factors are not separated')
    return a,b
