# Provenance of the structural sample

The fixed inputs are the literal rotations in `../data/fixtures.json.gz`.
Verification reconstructs their faces and checks sphere topology and girth; it
does not trust a generator's planarity label or a declared degree pattern.

The 76 excess-ten examples were constructed as follows: 20 examples of order 52
and 20 of order 70 by contracting specified cubic--cubic edges between hexagons
in flat source fixtures; 20 of order 106 by the same degree-excess-increasing
operation; and 16 of order 626 by a dual edge flip followed by specified triangle
mergers. The latter realize both mixed degree patterns, with one or two
degree-five vertices. Construction metadata is stored with each rotation.

Forty-four inherited flat examples and nine inherited boundary regressions were
added. Their original archives are identified by SHA-256 in
`../computation-record.json`. They include extra-chord and repeated-outside-contact
models and a nonvacuous all-pentagonal rigidity instance.

This is not a complete planar-graph enumeration. Failed or timed-out construction
attempts were not treated as nonexistence results. Random sampling and graph
transformation code were discovery aids only; a repeat of that search is not
needed to reproduce any verification result. The exact discovery search is not
included as a deterministic generator. The supplied literal inputs are the
complete, immutable inputs to the regression suite.
