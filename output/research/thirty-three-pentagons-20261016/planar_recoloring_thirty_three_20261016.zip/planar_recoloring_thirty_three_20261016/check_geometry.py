#!/usr/bin/env python3
"""Exact finite audits of the equality ledger and its local propagation steps."""
import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import sys
from plane import (need, rotation, spherical, girth_five, pentagons, patches,
                   separated, check_partner)
ROOT = Path(__file__).resolve().parent


def near_ledger(r, fs, owner, P):
    X, B = P['X'], P['B']
    DB = sum(len(r[v])-3 for v in B)
    FX = {i for i,f in enumerate(fs) if set(f)&X}
    FN = {i for i,f in enumerate(fs) if set(f)&(X|B)}
    pX = sum(len(fs[i]) == 5 for i in FX)
    near = sum(len(fs[i]) == 5 for i in FN)
    c = int(P['chord']); j = len(P['contacts'])-len(B)
    need(pX <= 9-c, 'sector bound for patch-incident pentagons')
    need(near <= 16-3*c-2*j+DB, 'coarse neighbourhood bound')
    need(near <= 15+DB, 'sharp neighbourhood bound')
    record = dict(near=near, DB=DB, score=near-DB, nu=15+DB-near,
                  chord=c, repeated_contacts=j)
    if c or j:
        return record
    candidates = []
    for v in B:
        row = r[v]
        for k, u in enumerate(row):
            w = row[(k+1)%len(row)]
            if u not in X and w not in X:
                candidates.append(owner[u,v])
    K = len(candidates)
    need(K == 7+DB, 'candidate-angle count')
    valid = Counter(i for i in candidates if len(fs[i]) == 5 and i not in FX)
    invalid = sum(len(fs[i]) != 5 or i in FX for i in candidates)
    dup = sum(n-1 for n in valid.values())
    need(near == pX+len(valid), 'new pentagons not covered by B angles')
    miss = 9-pX
    need(record['nu'] == miss+invalid+dup-1, 'exact local loss ledger')
    word = P['word']; q,z = word[:2]
    i = r[z].index(word[4])
    if r[z][(i+1)%3] == word[7]:
        special = owner[word[4],z]
    else:
        need(r[z][(r[z].index(word[7])+1)%3] == word[4], 'special corner')
        special = owner[word[7],z]
    need(special in FX and z in fs[special], 'special face location')
    need(q not in fs[special] or len(fs[special]) >= 7,
         'short third face cannot contain its hub across the existing edge')
    if len(fs[special]) == 5:
        b4, b7 = P['contacts'][4], P['contacts'][7]
        need(set(fs[special]) == {word[4],z,word[7],b4,b7}, 'long-sector pentagon')
        need(b7 in r[b4], 'missing exterior-neighbour edge')
        f,g = owner[b4,b7],owner[b7,b4]
        need(f != g and special in (f,g), 'edge-side face error')
        other = g if f == special else f
        need(candidates.count(other) >= 2, 'two candidate angles at the opposite face')
        need(invalid+dup >= 1, 'mandatory one-unit overcount')
        if record['nu'] == 0:
            need(all(len(fs[t]) == 5 for t in FN), 'saturated special-pentagon conclusion')
            need((miss,invalid,dup) == (0,0,1), 'one-unit equality pattern')
    elif record['nu'] == 0:
        need({t for t in FX if len(fs[t]) != 5} == {special},
             'only the special face can be a nonpentagon in a tight patch')
    record.update(special=special, special_length=len(fs[special]),
                  missing_X_pentagons=miss, invalid_B_angles=invalid, duplicate_B_angles=dup)
    return record


def global_ledger(r, fs, P, near):
    H = {v for v in r if len(r[v]) >= 4}
    a = sum(len(r[v]) == 4 for v in H)
    D = sum(len(r[v])-3 for v in H)
    e = sum(max(len(r[v])-5,0) for v in H)
    Q = sum(max(len(f)-6,0) for f in fs)
    p = sum(len(f) == 5 for f in fs)
    k = [len(set(f)&H) for f in fs]
    need(all(k[i] for i,f in enumerate(fs) if len(f) == 5), 'global ledger needs no ordinary pentagons')
    Delta = 3*len(H)+D-p
    heavy_nonpent = sum(sum(v in H for v in f) for f in fs if len(f) != 5)
    need(Delta == heavy_nonpent+sum(k[i]-1 for i,f in enumerate(fs) if len(f) == 5),
         'global heavy-incidence deficit')
    N = P['X']|P['B']
    far = [i for i,f in enumerate(fs) if len(f) == 5 and not(set(f)&N)]
    far_single = [i for i in far if k[i] == 1]
    far_multi = [i for i in far if k[i] >= 2]
    omega = Delta-len(far_multi)
    explained = heavy_nonpent
    for i,f in enumerate(fs):
        if len(f) == 5 and k[i] >= 2:
            explained += k[i]-2 if i in far else k[i]-1
    need(omega == explained and omega >= 0, 'defect-loss decomposition')
    capacity = 3*len(H)+D-3*a
    HB = H&P['B']
    CB = sum(1 if len(r[v]) == 4 else len(r[v]) for v in HB)
    sigma = capacity-1-CB-len(far_single)
    beta5 = sum(len(r[v]) >= 5 for v in P['B'])
    need(D-10-3*e-2*Q-3*beta5 == near['nu']+sigma+omega,
         'exact global equality ledger')
    overfull = {}
    for v in H-N:
        ids = [i for i in far_single if v in fs[i]]
        cap = 1 if len(r[v]) == 4 else len(r[v])
        if len(ids)>cap:
            need(len(r[v]) == 4, 'higher-degree capacity cannot be exceeded')
            overfull[v] = ids
    if sigma < 0:
        need(overfull, 'negative capacity slack has no overfull centre')
    if D == 10 and sigma >= 0:
        need((e,Q,beta5,near['nu'],sigma,omega) == (0,0,0,0,0,0),
             'D=10 saturation consequence')
        q = P['centre']
        need(sum(len(f) == 5 and set(f)&H == {q} for f in fs) == 4,
             'the initial hinge centre is not fully single-heavy')
        need(heavy_nonpent == 0, 'heavy vertex on a nonpentagonal face')
        need(all(k[i] == 1 for i,f in enumerate(fs) if len(f) == 5 and set(f)&N),
             'multi-heavy pentagon near a saturated hinge')
    return dict(sigma=sigma, omega=omega, beta5=beta5,
                heavy_nonpent=heavy_nonpent, overfull=overfull)


def full_centre_audit(r, fs, ps, ledgers):
    H = {v for v in r if len(r[v]) >= 4}
    C = {q for q in H if len(r[q]) == 4 and
         sum(len(f)==5 and set(f)&H == {q} for f in fs) == 4}
    eligible = []
    shortcuts = []
    for q in sorted(C):
        indices = [i for i,P in enumerate(ps) if P['kind']=='hinge' and P['centre']==q]
        need(len(indices)==4, 'fully clean centre must have four facial hinges')
        scores = [ledgers[i]['score'] for i in indices]
        if 15 in scores and min(scores)<15:
            shortcuts.append(dict(centre=q, scores=scores,
                                  face_pairs=[list(ps[i]['face_ids']) for i in indices]))
        if min(scores)!=15:
            continue
        domains = [ps[i]['X']|ps[i]['B'] for i in indices]
        allnear = set().union(*domains)
        # These are the additional hypotheses obtained from the global equality ledger.
        if any(len(r[v])>4 for v in allnear):
            continue
        if any(len(f)==5 and set(f)&allnear and len(set(f)&H)!=1 for f in fs):
            continue
        eligible.append(q)
        need(all(ledgers[i]['special_length']==5 for i in indices),
             'rotating the tight hinges did not eliminate the hexagon exception')
        need(all(len(f)==5 for f in fs if set(f)&allnear),
             'a fully saturated centre has a nonpentagon in its near region')
        for i in indices:
            need((ps[i]['B']&H)<=C, 'a heavy boundary vertex is not fully clean')
        source_faces = [i for i,f in enumerate(fs) if q in f]
        edgefaces = {}
        for j,f in enumerate(fs):
            for u,v in zip(f,f[1:]+f[:1]):
                edgefaces.setdefault(tuple(sorted((u,v))),[]).append(j)
        for i in source_faces:
            f=fs[i]
            for u,v in zip(f,f[1:]+f[:1]):
                for j in edgefaces[tuple(sorted((u,v)))]:
                    need(len(fs[j])==5 and len(set(fs[j])&C)==1,
                         'dual-adjacency closure at a saturated centre failed')
    if C and set(eligible)==C:
        need(all(len(f)==5 and len(set(f)&C)==1 for f in fs), 'global closure failed')
        need(H==C and len(C)==6, 'closed region must have six degree-four vertices')
    return C,eligible,shortcuts


def run():
    raw=json.loads(gzip.decompress((ROOT/'data/fixtures.json.gz').read_bytes()))
    counts=Counter(); score_hist=Counter(); deficit_hist=Counter(); models=Counter()
    records=[]; sharp=None; shortcut=None; saturated_no_surplus=[]
    for row in raw['fixtures']:
        r=rotation(row['rotation']);fs,owner=spherical(r);girth_five(r)
        need(min(map(len,r.values()))>=3, 'fixture minimum degree')
        H={v for v in r if len(r[v])>=4};D=sum(len(r[v])-3 for v in H)
        Q=sum(max(len(f)-6,0) for f in fs);p=sum(len(f)==5 for f in fs)
        o=sum(len(f)==5 and not(set(f)&H) for f in fs)
        need(p==12+2*D+Q, 'Euler face identity')
        if row['category']=='D10-no-ordinary':
            need(D==10 and Q==o==0, 'D10 fixture is outside the declared residue')
            need(sorted(len(r[v])for v in H) in
                 ([4]*10,[4]*8+[5],[4]*6+[5]*2), 'wrong D10 degree multiset')
        elif row['category']=='inherited-flat':
            need(D==6 and len(H)==6 and all(len(r[v])==4 for v in H), 'flat fixture degrees')
        ps=patches(r,fs);ledgers={};globs={};witness=None
        for i,P in enumerate(ps):
            if P['kind']!='hinge':continue
            L=near_ledger(r,fs,owner,P);ledgers[i]=L
            score_hist[L['score']]+=1;models['chorded' if P['chord'] else 'bare']+=1
            counts['near_ledgers']+=1
            if o==0:
                G=global_ledger(r,fs,P,L);globs[i]=G;counts['global_ledgers']+=1
                deficit_hist[(L['nu'],G['omega'])]+=1
                if D==10 and G['sigma']>=0:
                    saturated_no_surplus.append({'fixture':row['name'],'face_ids':list(P['face_ids']),'centre':P['centre']})
                if G['overfull'] and witness is None:
                    v=min(G['overfull']);ids=G['overfull'][v][:2]
                    check_partner(r,fs,P['face_ids'],ids)
                    witness={'first_faces':[list(fs[j]) for j in P['face_ids']],
                             'second_faces':[list(fs[j]) for j in ids],
                             'first_ids':list(P['face_ids']),'second_ids':ids}
            if L['score']==15 and sharp is None:
                sharp={'fixture':row['name'],'face_ids':list(P['face_ids']),'near':L['near'],'D_B':L['DB']}
        C,eligible,shortcuts=full_centre_audit(r,fs,ps,ledgers) if Q==0 else (set(),[],[])
        counts['full_centres']+=len(C);counts['locally_saturated_full_centres']+=len(eligible)
        if C and len(eligible)==len(C):counts['global_rigidity_instances']+=1
        if shortcut is None and shortcuts:
            shortcut={'fixture':row['name'],**shortcuts[0]}
        if D==10:
            need(witness is not None, 'D10 fixture has no verified separated partner')
        records.append({'name':row['name'],'category':row['category'],'vertices':len(r),
                        'heavy_degrees':sorted(len(r[v])for v in H),'D':D,'Q':Q,
                        'pentagonal_faces':p,'distinct_pentagons':len(pentagons(r)),
                        'ordinary_faces':o,'hinges':len(ledgers),'fully_clean_centres':len(C),
                        'saturated_full_centres':len(eligible),'witness':witness})
    need(sharp is not None, 'missing sharp-bound regression')
    return {'status':'PASS','scope':'Exact checks on the explicitly stored, non-exhaustive sample. No complete recolouring graph is enumerated. Algebra and local geometry regressions are not a formal verification of the analytic proof.',
            'fixture_count':len(records),'D10_fixtures':sum(x['D']==10 for x in records),
            'counts':dict(counts),'patch_models':dict(models),
            'near_score_histogram':dict(sorted(score_hist.items())),
            'local_and_global_loss_histogram':{f'{a},{b}':n for (a,b),n in sorted(deficit_hist.items())},
            'sharp_bound_example':sharp,'single_tight_patch_does_not_suffice':shortcut,
            'D10_tight_patches_with_no_capacity_surplus':saturated_no_surplus,
            'fixtures':records}


def main():
    need(not sys.flags.optimize,'optimized Python is not supported')
    p=argparse.ArgumentParser();p.add_argument('--write-reports',action='store_true');args=p.parse_args()
    text=json.dumps(run(),sort_keys=True,indent=2)+'\n';target=ROOT/'reports/geometry.json'
    if args.write_reports:target.write_text(text)
    else:need(target.read_text()==text,'geometry report differs')
    print('PASS equality ledgers and local propagation')
if __name__=='__main__':main()
