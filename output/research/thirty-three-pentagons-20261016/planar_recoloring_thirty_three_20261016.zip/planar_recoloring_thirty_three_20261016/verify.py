#!/usr/bin/env python3
"""Read-only exact finite regression replay for the excess-ten equality proof."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
READERS=('check_geometry.py','check_algebra.py','check_negative.py')


def need(ok,message):
    if not ok:raise ValueError(message)


def manifest():
    m=json.loads((ROOT/'manifest.json').read_text())['files']
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
            and p.name!='manifest.json' and '__pycache__' not in p.parts}
    need(actual==set(m),'manifest file set differs')
    for name,meta in m.items():
        b=(ROOT/name).read_bytes()
        need(len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'],
             'manifest hash mismatch: '+name)
    print('PASS manifest',len(m),'files')


def main():
    need(not sys.flags.optimize,'optimized Python is not supported')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--write-reports',action='store_true')
    p.add_argument('--check-manifest',action='store_true')
    a=p.parse_args()
    if a.check_manifest:manifest();return
    for name in READERS:
        subprocess.run([sys.executable,'-B',str(ROOT/name)]+
                       (['--write-reports']if a.write_reports else []),cwd=ROOT,check=True)
    read=lambda name:json.loads((ROOT/'reports'/name).read_text())
    g=read('geometry.json');z=read('algebra.json');n=read('negative.json')
    r={'status':'PASS','readers':len(READERS),'fixtures':g['fixture_count'],
       'D10_fixtures':g['D10_fixtures'],'near_ledgers':g['counts']['near_ledgers'],
       'global_ledgers':g['counts']['global_ledgers'],
       'fully_clean_centres':g['counts']['full_centres'],
       'locally_saturated_full_centres':g['counts']['locally_saturated_full_centres'],
       'global_rigidity_instances':g['counts']['global_rigidity_instances'],
       'scalar_identity_checks':z['scalar_identity_checks'],
       'valid_four_attachment_degree_words':len(z['four_attachment_chains']),
       'circular_word_checks':z['circular_word_checks'],
       'bounded_low_p_tuples':z['low_p_tuple_count'],'bounded_low_D_tuples':z['low_D_tuple_count'],
       'corruptions_rejected':n['count'],'new_colouring_cycle_certificates':0,
       'new_full_recolouring_graphs_enumerated':0,
       'scope':'Exact finite geometry/algebra regressions only. Analytic proofs and inherited local restoration implications are not machine-certified by these readers.'}
    text=json.dumps(r,sort_keys=True,indent=2)+'\n';target=ROOT/'reports/verification-summary.json'
    if a.write_reports:target.write_text(text)
    else:need(target.read_text()==text,'verification summary differs')
    print('PASS all three new readers')
if __name__=='__main__':main()
