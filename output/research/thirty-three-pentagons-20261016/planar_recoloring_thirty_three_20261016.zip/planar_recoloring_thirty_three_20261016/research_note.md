# Thirty-three pentagons: rigidity at total excess ten

Research date: 2026-10-16.

## 1. Results and dependency boundary

All graphs are finite and simple. P5 denotes the nonempty planar graphs of girth
at least five. Colours are labelled; a proper colouring need not use every colour.
Two recolouring states are adjacent exactly when one original vertex changes.
A heavy vertex has original degree at least four. Put

    D(G) = sum_v max(d_G(v)-3, 0).

Relative to the explicitly identified inherited restoration lemmas, this note proves:

**Theorem A.** Every G in P5 with D(G) <= 10 has Hamiltonian R_k(G) for every k >= 4.

**Theorem B.** Every G in P5 with at most thirty-three distinct 5-cycles has
Hamiltonian R_k(G) for every k >= 4. No maximum-degree or two-degeneracy
qualification is imposed on this theorem.

**Theorem C.** The same conclusion holds in either two-degenerate subclass:
(i) at most thirty-seven distinct 5-cycles; (ii) D(G) <= 15.

All four class conditions are hereditary under vertex deletion. Each has uniform
Hamiltonian threshold exactly four. Distinct cycles, rather than faces in one
embedding, are counted in Theorems B and C(i).

The new part is analytic: an equality-rigidity argument for D=10, and stronger
low-degree exclusions. No new local colouring-cycle certificate is introduced.
The exact readers check finite geometry and algebra regressions, not the universal
proof text. No independent human review or Lean verification is claimed.
Unrestricted h(P5)=4 is not proved; no four-colour Hamilton-connectedness result
is asserted.

### Inherited premises

From the manuscript and preceding packages, with their original-degree and
induced-subgraph hypotheses:

* product and degree-at-most-one reductions; independent-set restoration;
* any two ordinary facial pentagons supply a precise restorable deletion;
* a degree-four single-heavy shared-edge pentagon pair (a hinged pair), together
  with a separated ordinary pentagon, another hinged pair, or a bowtie;
* ordinary-pentagon and single-heavy two-face configurations with a degree-two
  reservoir; the clean-face capacity consequences from the thirty-one package;
* shared-hub regular P4/P5 and one-degree-four P5 paths, star3, tailed5, and the
  P7/P10 two-/three-face fan reductions;
* the triangle-free planar theorem for every palette k >= 5.

The following analytic statements from the thirty-one package are used explicitly:
its sharp 15+D_B neighbourhood bound; its unique-ordinary-pentagon reduction for
D<=11; its D<=9 theorem; and its strengthened common-hub inequality with clean
capacity one. Their exact roles are restated below. The new D=10 argument does
not assume Theorem A or B in obtaining a local restoration configuration.

The repository was re-read at SctHy/planar_recoloring main commit
`f229669c4fada686b389559be7e831b265b4b0c9`. Its article still contains the
nine-pentagon theorem. No GitHub file, branch, commit or publication bundle was
modified. The new LaTeX fragment is additive and uncompiled.

## 2. The equality ledger for a hinged pair

Work first in a connected plane graph G of minimum degree at least three and
girth at least five, with no ordinary facial pentagons. Let a count degree-four
vertices, b count vertices of degree at least five, h=a+b, and

    e = sum_(d(v)>=6)(d(v)-5),
    D = a+2b+e,
    Q = sum_(faces F, |F|>=7)(|F|-6).

Euler gives p=12+2D+Q pentagonal faces. The exact heavy-incidence deficit is

    Delta = 3h-D-12-Q
          = heavy incidences on nonpentagonal faces
            + sum_(multi-heavy pentagons F)(k(F)-1),

where k(F) is the number of heavy vertices on F. Incidences on a nonsimple
nonpentagonal face are counted with multiplicity.

Let X be the induced union of two facial pentagons sharing an edge whose unique
heavy vertex q has degree four. Its two possible induced models and their
restorations are inherited. Put B=N(X) minus X and D_B=sum_(v in B)(d(v)-3).
Call a pentagon near if it meets X union B, and far otherwise.

The sharp inherited neighbourhood lemma says

    near <= 15+D_B.

Define its nonnegative deficit

    nu_X = 15+D_B-near.

The single-heavy capacity is one at a degree-four vertex and d(v) at a higher
vertex. Its total is C=3h+D-3a. Let C_B be the sum of these capacities at the
heavy vertices in B, and let f_1,f_2 count far pentagons with exactly one and
at least two heavy vertices, respectively. Put

    sigma_X = C-1-C_B-f_1,
    omega_X = Delta-f_2.

If no hinged pair or bowtie is separated from X, then sigma_X>=0: two far
single-heavy pentagons at a nonattached degree-four vertex give such a partner.
The higher-degree capacity d(v) is an unconditional angle bound. Always
omega_X>=0. More explicitly, with

    E = heavy incidences on nonpentagonal faces
        + sum_(multi-heavy pentagons F)(k(F)-2),

we have

    omega_X = E + number of near multi-heavy pentagons.       (2.1)

Let beta_+ count the vertices of B of degree at least five. Since
D_B-C_B=-3beta_+, subtraction gives the EXACT identity

    nu_X + sigma_X + omega_X
        = D-10-3e-2Q-3beta_+.                               (2.2)

This identity also holds on examples with a separated partner; sigma_X may then
be negative. The regression reader checks that a negative value exhibits an
actual overfull degree-four centre and a valid separated partner. It does not
assume sigma is nonnegative on arbitrary graphs.

## 3. What a sharp local neighbourhood count forces

Use the standard hinge labels

    (0,2,3,4,1), (0,1,7,6,5),

with heavy vertex 0 and shared light endpoint 1. A chord, when present, is 36.
The bare contact vertices are 0,2,3,4,5,6,7.

Suppose nu_X=0. The coarse inherited bound is

    near <= 16-3c-2j+D_B,

where c is zero or one according to the chord and j is the number of repeated
outside contacts. Thus c=j=0: the hinge is bare and its seven outside neighbours
are distinct.

Let F_X be all faces meeting X, and let p_X count their pentagons. There are at
most nine faces in F_X (two chosen faces and seven outside sectors). At each
v in B exactly d(v)-2 angles avoid its single edge to X. There are therefore

    K = 7+D_B

candidate B-angles for additional pentagons. Let U count those candidate angles
whose face is not pentagonal or already meets X. For each new pentagon count
its multiplicity among the remaining angles, and let V be the sum of the
multiplicities minus one. Then

    nu_X = (9-p_X)+U+V-1.                                  (3.1)

Call the third face at vertex 1, through the corner 4-1-7, the special face.
If it is pentagonal, it has boundary

    (4,1,7,b_7,b_4),

where b_4,b_7 are the corresponding outside neighbours. In particular b_4b_7
is an edge. Its other side uses two of the candidate B-angles. If it is a new
pentagon, these give at least one duplicate; otherwise both candidates are
unused. Therefore U+V>=1.

In equality, (3.1) now forces p_X=9, U=0 and V=1. All faces meeting X are
pentagonal, and all candidate B-angles lie on new pentagons. Consequently:

**Local equality fact.** If the special face is pentagonal and nu_X=0, every
face meeting X union B is pentagonal.

If the special face is not pentagonal, it already uses one unit of 9-p_X.
Equality forces it to be the ONLY nonpentagonal face meeting X. These assertions
are derived from actual angles and distinct faces; they do not require each
candidate angle to represent a different face.

## 4. Propagation around fully single-heavy centres

The following is the new rigidity lemma.

**Lemma R.** Suppose G is connected, has minimum degree at least three, girth
at least five, and every face has length five or six. Let C be the set of
degree-four vertices whose four incident faces are pentagons with that vertex
as their unique heavy vertex. Suppose C is nonempty, and EVERY facial hinge X
centred at a vertex of C has:

1. nu_X=0;
2. no vertex of degree greater than four in B=N(X) minus X;
3. exactly one heavy vertex on every pentagon meeting X union B.

Then every face of G is a pentagon with exactly one degree-four vertex, all
heavy vertices belong to C, and D(G)=6.

### 4.1 Rotate all four hinges to remove the hexagon exception

Facial walks are simple here. Indeed a nonsimple cyclically nonbacktracking
facial walk can be split at a repeated vertex into two nonempty closed walks,
each containing a cycle; its length is at least ten in girth five.

Fix q in C. Its four pentagons give four hinges, one for each adjacent pair of
angles. Each neighbour z of q occurs in exactly THREE of those hinge unions;
their special endpoints are three distinct neighbours of q.

Suppose the third face at z is a hexagon. It meets all three hinges containing
z. By Section 3 it must be the special face of all three. It would therefore
contain three distinct neighbours of q, but not q itself (all q-faces are
pentagons). This is impossible: among three vertices of a 6-cycle two have cycle
distance at most two, and the two edges to q would close a triangle or four-cycle.

Thus all four special faces are pentagonal. Section 3 then shows that all faces
meeting X union B are pentagons, for every hinge at q. By hypothesis they have
exactly one heavy vertex. In particular every heavy vertex in such a B is in C:
it has degree four, and all its incident faces are single-heavy pentagons.

### 4.2 Check each exterior side of a q-pentagon

Write one q-face as

    F=(q,a,b,c,d),

where a,d are neighbours of q. A neighbouring face across qa or qd already
contains q. The third face at a, which is the exterior neighbour across ab,
is the special face of the hinge at a. Its unique heavy vertex is one of that
hinge's B-vertices, and therefore belongs to C. The same holds across cd.

It remains to treat the exterior face across bc. The third neighbours p of b
and r of c lie outside either hinge containing F: all these hinges are bare.
That exterior face is a pentagon

    H=(b,c,r,z,p).

If p or r is heavy, it lies in the B-set of such a hinge, hence in C, as required.
Suppose both are light. Then z is heavy.

Use the hinge consisting of F and the q-face on its other side at a. Its special
face has the form

    J=(b,a,b',h,p).

Since b,a,b',p are light, h is its heavy vertex. At p, the two distinct faces J,H
are on the two sides of edge pb. Original degree three makes their next
neighbours h,z distinct. The third face at p contains BOTH h and z. But p lies
in B for this hinge, and Section 4.1 says every such face is a single-heavy
pentagon. This is a contradiction.

Hence H also contains a vertex of C. Every face adjacent to a face containing
C therefore contains C.

### 4.3 Close the region and apply Euler

The plane dual is connected. The nonempty set of faces containing C is closed
under face adjacency, so it comprises every face of G. All those faces are
single-heavy pentagons. Any heavy vertex appears on a face, and must be its
unique C-vertex. Thus all heavy vertices are in C and have degree four.

If c=|C|, incidence counting gives p=4c, while Euler gives p=12+2c. Therefore
c=D(G)=6. This proves Lemma R. No contraction, global three-colouring, or
classification of all pentangulations is needed. QED.

## 5. Eliminate D=10

**Structural theorem.** Every connected plane graph of minimum degree at least
three, girth at least five, and D(G)<=10 has a configuration covered by the
new or inherited restoration lemmas.

D<=9 is inherited. For D=10, two ordinary facial pentagons are reducible; a
unique ordinary pentagon is handled by the inherited D<=11 lemma. Assume
there are none.

As in Section 2 let a count degree four. At most 2Delta of their face incidences
are non-single-heavy, so there are at least 4a-2Delta single-heavy incidences.
Since

    a-Delta=12-h+e+Q>0,   h<=D=10,

some degree-four vertex has at least three single-heavy pentagons. Two are
adjacent; choose their hinge X.

Assume no hinge has a separated hinged/bowtie partner. For every such X, all
three left-hand terms in (2.2) are nonnegative. At D=10 it follows that

    e=Q=beta_+=nu_X=sigma_X=omega_X=0.                       (5.1)

By (2.1), no heavy vertex lies on a nonpentagonal face, and no multi-heavy
pentagon is near X. Therefore the initial centre, already on three single-heavy
pentagons, has all four faces single-heavy. The set C in Lemma R is nonempty.

Equation (5.1) applies to EVERY hinge at EVERY centre of C, not just the initially
selected pair. It supplies all three hypotheses of Lemma R. That lemma gives
D=6, contradicting D=10. Thus a separated partner exists and the inherited
protected-product restoration applies. QED.

The use of all four rotated hinges is explicit. A single numerical equality
is not silently promoted to an unbounded region-closure statement.

## 6. A four-attachment chain consumes at least two units

Here we work in a minimal counterexample with degree-two vertices and use the
thirty-one package's clean capacity ONE. This part is independent of Sections
2--5.

For s>=2 write

    S={u_1,...,u_s}, N(u_i)={w,x_i}, d(w)=s+t,
    D'=sum_(heavy v!=w)(d(v)-3),
    e=sum_(v!=w,d(v)>=6)(d(v)-5).

All x_i are distinct. The t=0 star is reducible. Put b=2t-p0, where p0 counts
pentagons having no heavy vertex other than w. Let kappa=0 for s>=3 and
kappa<=1 for s=2; an exceptional centre requires both x_1,x_2 to have degree
three. Let a count the other degree-four vertices, C their clean incidences,
and use the inherited nonnegative slacks

    delta=a+kappa-C,
    W=N4+2N+ + sum_(multi-heavy pentagons F)[2(a(F)-1)-a4(F)].

The exact inherited angular argument gives

    D' >= 12+b-kappa+2Q+3e+delta+W,                         (6.1)
    p >= 30+2t+2b-2kappa+5Q+6e+2delta+2W.                  (6.2)

The hub fan reductions imply b>=1, and b>=2 whenever t>=2. To justify the
latter for all t: two Z-runs each cost at least one; a single run of length at
least three has at least two ZZ angles; a length-two run costs at least two
by the inherited P10 reduction. A pair of runs of lengths one and two costs
at least three.

**Chain lemma.** Suppose t=1, s>=4, Q=e=0, and delta+W<=1. Then the graph is
reducible, a contradiction.

All faces are simple pentagons or hexagons, and all other heavy degrees are
four or five. There are s-1 distinct SS faces in path order. A hexagonal SS
face with no heavy vertex or just one degree-four vertex is an inherited P5
reduction. Any remaining one costs at least two in W. Hence every SS face
must be pentagonal.

For consecutive attachments its pair of original degrees is therefore one of

    (4,4), (4,5), (5,4), (5,5), (5,3), (3,5).

The excluded (3,3) and (3,4) pairs are regular/one-heavy P4 reductions.
Consider any four consecutive attachments x1,x2,x3,x4. If an internal x2 or
x3 is light, both its attachment-neighbours have degree five. Its third face
contains both distinct degree-five vertices, costing at least two in W,
contrary to the budget.

Otherwise x2,x3 are both heavy. A degree-four one has two heavy attachment
neighbours: a light neighbour would give an excluded (4,3) pair. At that
vertex the two heavy-neighbour edges flank its edge to u_i. The other two
angles both contain a heavy neighbour; the two angles at u_i contain w.
It has NO clean face, costing one unit of delta.

If both internal vertices have degree four, delta>=2. If exactly one has
degree five, the intervening SS pentagon costs one in W and the degree-four
vertex costs one in delta. If both have degree five, that pentagon costs two
in W. All cases contradict delta+W<=1. QED.

This proof uses only four consecutive positions and therefore works for
arbitrarily long S-runs. The bounded word checks are regressions, not an
extrapolation in s.

## 7. Degree-two exclusion through 37 pentagons and excess 15

The inherited unique-degree-two bound is p>=42 and D>=16. Assume s>=2.

### 7.1 At most thirty-seven pentagons

For s=2, t>=2 and b>=2. Equation (6.2) with p<=37 forces

    t=b=2, kappa=1, Q=e=delta=W=0, D'=13, p=36.

Both attachments are light. An SS pentagon is a regular P4 reduction. An SS
hexagon has a middle vertex of degree three, four, or five; the first two
are inherited P5 reductions, and the last costs two in W. There is no SS
angle, so the neighbour order alternates. Since p0=4-b=2, a mixed p0-pentagon,
together with the other degree-two neighbour, is the inherited tailed5
configuration.

For s>=3, kappa=0. Equation (6.2), with b>=2 when t>=2, forces

    t=1, Q=e=0, delta+W<=1.

If s=3 the hub has degree four and star3 applies. Otherwise the chain lemma
applies. Thus a minimal counterexample containing a degree-two vertex has
at least THIRTY-EIGHT pentagonal faces.

### 7.2 Total excess at most fifteen

The hub contributes s+t-3 to D, so (6.1) implies

    D >= 9+s+t+b-kappa+2Q+3e+delta+W.                       (7.1)

For s>=3, star3 removes (s,t)=(3,1). All other possibilities already force
D>=16, except (s,t)=(4,1). Under D<=15 that exception requires
b=1, D'=13 and Q=e=delta=W=0; the chain lemma removes it.

For s=2, t>=2. If t>=4, (7.1) already gives D>=16. For t=3, D<=15 forces
kappa=1, b=2, D'=13 and Q=e=delta=W=0. Both attachments are light, so the
SS-angle argument above excludes adjacency of the S-neighbours. Their two
Z-runs have lengths one and two, costing at least three in b, a contradiction.

For t=2 the hub has degree four and D'<=14. If kappa=0, (6.1) gives b=2 and
Q=e=delta=W=0. Since p0=2 and a ZZ face accounts for at most one p0-face, some
p0-face is mixed. It and the other degree-two neighbour give tailed5.

If kappa=1, then b<=3, Q=e=0 and delta+W<=1. The light-attachment SS argument
again leaves an alternating order. Now p0=4-b>=1; every p0-face is mixed,
and tailed5 applies.

This proves that EVERY minimal counterexample containing degree-two vertices
has D>=16. Together with Section 7.1:

    degree-two vertices imply p>=38 and D>=16;
    exactly one degree-two vertex still implies p>=42.

The inequalities constrain minimal counterexamples only; they are not lower
bounds for arbitrary colourable planar graphs.

## 8. Class proofs, larger palettes and sharpness

For Theorem A, choose a smallest four-colour counterexample in D(G)<=10.
Products handle disconnected graphs, a singleton has colouring graph K4,
and the one-vertex lift excludes degree at most one. The inherited low-degree
bound (or the strengthened Section 7) excludes degree two. The graph has
minimum degree at least three, and Section 5 supplies a precise restorable
deletion. Apply induction and its inherited local restoration.

For Theorem B, a smallest counterexample with at most 33 distinct pentagons
has no degree-two vertex by Section 7. Euler gives 12+2D+Q=p<=33, so D<=10.
Theorem A applies. There is no assumption that this full class is two-degenerate.

For either class in Theorem C, the low-degree reductions leave minimum degree
at least two. Two-degeneracy forces a degree-two vertex in that graph itself.
Section 7 contradicts p<=37 or D<=15, respectively.

For every k>=5, use the inherited triangle-free planar theorem (or degeneracy
for the two-degenerate classes). The graph C6 belongs to all four classes and
its proper three-colouring 012012 is frozen. Thus the thresholds are exactly
four. Dependency order is the new structural/low-degree lemmas, Theorem A,
then B and C. No larger-palette monotonicity is assumed.

## 9. The next one-unit residue (not a solved class)

A full-class counterexample now needs at least 34 distinct pentagons and D>=11.
A globally order-minimal counterexample with at most 35 pentagons cannot have
degree-two vertices, by p>=38. It has minimum degree at least three. Euler,
Theorem A and the inherited unique-ordinary D<=11 lemma leave

    D=11, Q=e=0, p=34, and no ordinary facial pentagon.

The possible heavy-degree counts (number of degree-four, degree-five vertices)
are (11,0), (9,1), (7,2), (5,3). Every other vertex has degree three.

For any facial hinge in a hypothetical no-partner graph, (2.2) reads

    nu_X+sigma_X+omega_X=1,    beta_+=0.                    (9.1)

One further necessary restriction follows from the rigidity argument. With E
as in (2.1), suppose E>=1. Then every hinge has E=omega_X=1 and nu_X=sigma_X=0,
and no multi-heavy pentagon is near any hinge. A hinge exists by the same
C4>2a count, since h<=11<12.

Its centre has no nonpentagonal face: in a tight patch the only possible
nonpentagon meeting X is its special face at the shared light endpoint. That
5-/6-cycle cannot also contain the centre without the existing centre--endpoint
edge becoming a chord, forbidden by girth. With no multi-heavy pentagon near X,
the centre is fully single-heavy. All full centres satisfy Lemma R, which would
give D=6. Contradiction. Therefore E=0.

Thus every hexagon avoids heavy vertices and every multi-heavy pentagon contains
exactly two heavy vertices. Moreover no degree-five vertex belongs to such a
multi-heavy pentagon. Otherwise all degree-five vertices lie outside every
X union B (beta_+=0), and at least one unit of their single-heavy capacity is
missing in EVERY far-face count. Hence sigma_X>=1 for every hinge. Equation
(9.1) again forces nu_X=omega_X=0 everywhere, and Lemma R gives the same
contradiction.

The remaining binary-heavy pentagons therefore join degree-four vertices only.
This is a NECESSARY one-unit-deficit regime, not its elimination. The new work
does not establish unrestricted h(P5)=4, a full 35-pentagon theorem, or an
unrestricted D<=11 theorem.

## 10. Finite verification and limitations

Run, from the delivered directory:

    python3 -B verify.py
    python3 -B verify.py --check-manifest

Readers use only the standard library. Default replay is read-only and compares
reports byte for byte; --write-reports is explicit. Optimized Python is rejected.

The literal structural sample includes 76 D=10 graphs, covering all three
residual degree multisets. Forty have orders 52 or 70, twenty have order 106,
and sixteen have order 626. These were obtained by specified contraction or
dual-flip/face-merger constructions, then stored as exact rotations. They have
no ordinary face, and each has an explicit checked separated partner. The
sample is NOT exhaustive; isomorphic duplicates are retained. Unsuccessful
construction searches are not converted into nonexistence claims.

Forty-four inherited flat fixtures include PI and larger hexagonal extensions.
Nine inherited boundary regressions include the chorded and shared-neighbour
cases. The reader checks spherical rotations, girth, distinct pentagons, the
exact local and global loss ledgers, the special-face step, and the rotated
full-centre implications on every applicable patch. PI supplies a nonvacuous
instance of the global all-pentagonal rigidity conclusion D=6. The finite D=10
sample is not claimed to realize a no-partner equality case.

The final new-suite replay checks 2,482 local loss ledgers, 2,480 global
ledgers, and 513 fully clean centre instances across the 129 fixtures. Six
locally saturated centres occur in the 38-vertex PI fixture; that fixture
nonvacuously satisfies the global rigidity conclusion D=6. There are 18,000
scalar identity substitutions, 31 admissible four-attachment degree words,
1,703 circular-word regressions and eight corruptions rejected. These counts
refer to the declared stored inputs, not a complete graph enumeration.

The algebra reader checks the exact scalar subtraction, the four-spoke rotation
table, all allowed hub-neighbour subsets of a six-cycle, all four-attachment
degree words, the bounded low-p case extraction, and the complete D<=15 case
extraction. The low-p regression samples finitely many values of s; the analytic
chain proof covers every s>=4. Numerical case checks do not certify the universal
face-counting proofs.

No new full recolouring graph or product cycle is enumerated by these readers.
The inherited replay record distinguishes completed readers from execution-limit
attempts. The new proof does not claim independent verification of all older
analytic arguments or a replay of the complete original article supplement.
No original article compilation, Lean proof, independent human review, GitHub
write or source-repository commit is claimed.

### Actual inherited replays in this continuation

The thirty-one package's seed/row, independent-interface, hinged clique-tree,
ordinary component-block, bowtie clique-tree/interface, and obstruction readers
passed separately. Its manifest passed. The complete eleven-pentagon suite
passed, including its seven full-graph regressions on 244,836 colouring states;
its exact manifest function was also invoked successfully. Receipts and stdout
are in reports/inherited/. Those older full-graph states are NOT new graphs
constructed by this continuation.

The full thirty-one suite, its expensive product reader, and its full structural
regression reader were attempted but did not finish within the execution limits.
A separate combined eleven-suite/manifest attempt also hit a limit; the completed
suite and direct manifest runs are recorded independently. No incomplete attempt
is counted as a passing suite. The preceding analytic results remain stated
dependencies, not results whose entire original proof chain was reverified here.

The final read-only execution of the THREE NEW readers completed successfully
with unchanged report hashes. See reports/current-verification.json.
